package main

import (
    //"fmt"
    "github.com/astaxie/beego"
)

type HomeController struct {
    beego.Controller
}

func (this *HomeController) Get() {
    this.Ctx.WriteString("Hello Beego FrameWork!")
}

func main() {
    beego.Router("/", &HomeController{})
    beego.Run()
}
